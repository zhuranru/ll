#ifndef __BUZZER_H
#define __BUZZRT_H

void smart_security_thread(void *arg);

#endif