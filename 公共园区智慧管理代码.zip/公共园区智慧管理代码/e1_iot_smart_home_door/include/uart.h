#ifndef __UART_H
#define __UART_H

void uart2_process(void);

#endif