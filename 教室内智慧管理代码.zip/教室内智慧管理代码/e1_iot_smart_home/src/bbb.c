/*
 * Copyright (c) 2024 iSoftStone Education Co., Ltd.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include "smart_security.h"

#include <stdbool.h>
#include <stdio.h>

#include "lcd.h"
#include "mq2.h"

#include "iot_pwm.h"
#include "iot_gpio.h"

#define BEEP_PORT EPWMDEV_PWM5_M0
#define GPIO_ALARM_LIGHT GPIO0_PA5
#define GPIO_BODY_INDUCTION GPIO0_PA3

static bool body_induction_state = false;

/***************************************************************
 * 函数名称: mq2_init
 * 说    明: mq2初始化
 * 参    数: 无
 * 返 回 值: 无
 ***************************************************************/
void mq2_init(void)
{
    mq2_dev_init();
    mq2_ppm_calibration();
}

/***************************************************************
 * 函数名称: mq2_read_data
 * 说    明: 读取mq2传感器数据
 * 参    数: 无
 * 返 回 值: 无
 ***************************************************************/
void mq2_read_data(double *dat)
{
    *dat = get_mq2_ppm();
}

/***************************************************************
 * 函数名称: beep_dev_init
 * 说    明: 蜂鸣器初始化
 * 参    数: 无
 * 返 回 值: 无
 ***************************************************************/
void beep_dev_init(void)
{
    IoTPwmInit(BEEP_PORT);
}

/***************************************************************
 * 函数名称: beep_set_pwm
 * 说    明: 设置蜂鸣器PWM
 * 参    数: 无
 * 返 回 值: 无
 ***************************************************************/
void beep_set_pwm(unsigned int duty)
{
    IoTPwmStart(BEEP_PORT, duty, 1000);
}

/***************************************************************
 * 函数名称: beep_set_state
 * 说    明: 设置蜂鸣器状态
 * 参    数: 无
 * 返 回 值: 无
 ***************************************************************/
void beep_set_state(bool state)
{
    static bool last_state = false;

    if (state == last_state)
    {
        return;
    }

    if (state)
    {
        beep_set_pwm(20);
    }
    else
    {
        beep_set_pwm(1);
        IoTPwmStop(BEEP_PORT);
    }

    last_state = state;
}







